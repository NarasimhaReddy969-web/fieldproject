import { BrowserRouter, Routes,Route } from "react-router-dom";
import Home from './Home';
import Register from './Register';
import Login from './Login';
import Library from "./Library";
import Admin from "./Admin";
import Addbook from "./books/AddBook";
import AuthorBook from "./books/AuthorBook";
import ViewAll from "./books/ViewAll";
function App(){
  return(
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/reg" element={<Register/>}/>
          <Route path="/log" element={<Login/>}/>
          <Route path="/admin" element={<Admin/>}/>
          <Route path="/library" element={<Library/>}/>
          <Route path="/vauthorbooks" element={<AuthorBook/>}/>
          <Route path="/abook" element={<Addbook/>}/>
          <Route path="/viewall" element={<ViewAll/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}
export default App