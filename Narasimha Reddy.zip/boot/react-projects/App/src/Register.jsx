import { useState } from "react"
import axios from "axios"
function Register(){
    const[form,setform]=useState(
        {
            username:"",
            email:"",
            password:"",
        }
    )
    const changedata=(e)=>
        {
            setform({...form,[e.target.name]:e.target.value})
        }
    const submitform = async (e) => {
        e.preventDefault()
        try{
        const response=await axios.post("http://localhost:1234/register",form)
        alert(response.data)
        }
        catch(error){
            console.log(error)
            alert("Registration Failed")
        }
        
};

    return(
        <>
            <h1>Registration page</h1>
            <p>{form.username}</p>
            <p>{form.email}</p>
            <p>{form.password}</p>
            <form onSubmit={submitform}> 
                <input onChange={changedata}type="text" name="username" placeholder="create name"/><br/>
                <input onChange={changedata}type="email" name="email" placeholder="enter email"/><br/>
                <input onChange={changedata}type="password" name="password" placeholder="enter password"/><br/>
                <button type="submit">Register</button><br/>
            </form>
        </>
    )
}
export default Register