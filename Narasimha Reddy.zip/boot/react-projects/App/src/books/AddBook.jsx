import { useState } from "react";
import axios from "axios";

function Addbook() {
    const [form, setform] = useState({
        title: "",
        author: "",
        description: "", 
    });

    const changedata = (e) => {
        setform({ ...form, [e.target.name]: e.target.value });
    };

    const submitform = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:1234/book/addbook", form);
            console.log(response);
            alert(response.data);
        } catch (error) 
        {
            if(error.response && error.response.status === 409)
            {
                alert(ErrorEvent.response.data)
            }
            else{
                alert("something went worng")
            }
           
            
        }
    };

    return (
        <>
            <h1>Add a new book</h1>
            <form onSubmit={submitform}>
                <input onChange={changedata} type="text" name="title" placeholder="Enter title" /><br />
                <input onChange={changedata} type="text" name="author" placeholder="Enter author" /><br />
                <input onChange={changedata} type="text" name="description" placeholder="Enter description" /><br />
                <button type="submit">Add Book</button><br />
            </form>
        </>
    );
}

export default Addbook
