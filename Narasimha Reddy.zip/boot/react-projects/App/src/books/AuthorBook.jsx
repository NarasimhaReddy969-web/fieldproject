import { useState } from "react";
import axios from "axios";

function AuthorBook() {
    const [form, setForm] = useState("");  
    const [result, setResult] = useState([]);  

    const changedata = (e) => {
        setForm(e.target.value);  
    };

    const submitform = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(`http://localhost:1234/book/authorform/${form}`);
            setResult(response.data);
        } catch (error) {
            console.error("Error submitting form:", error);
        }
    };

    return (
        <>
            <h1>Add an Author Name</h1>

            <form onSubmit={submitform}>
                <input onChange={changedata} type="text" name="author" placeholder="Enter author name" value={form} />
                
                <button type="submit">get books</button>
                <br />
            </form>

            {/* Render result if it's an array */}
            <ul>
                {result.map((x, index) => (
                    <li key={index}>
                        {x.title} {x.author} {x.description}
                    </li>
                ))}
            </ul>
        </>
    );
}

export default AuthorBook;