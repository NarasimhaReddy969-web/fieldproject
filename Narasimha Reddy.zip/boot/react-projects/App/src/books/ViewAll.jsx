import axios from "axios";
import { useEffect, useState } from "react";

function ViewAll() {
  const [books, setBooks] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const fetchBooks = async (pageNumber) => {
    try {
      const response = await axios.get(`http://localhost:1234/book?page=${pageNumber}&size=5`);
      setBooks(response.data.content);
      setTotalPages(response.data.totalPages);
      setPage(response.data.number);
    } catch (error) {
      console.error("Error fetching books", error);
    }
  };

  useEffect(() => {
    fetchBooks(0);
  }, []);

  const handleNext = () => {
    if (page + 1 < totalPages) {
      fetchBooks(page + 1);
    }
  };

  const handleBack = () => {
    if (page > 0) {
      fetchBooks(page - 1);
    }
  };

  return (
    <>
      <h1>View all books</h1>
      <h2>Book List(page{page + 1})</h2>
      <ul>
        {books.map((b) => (
          <li key={b.id}>{b.title} - {b.author}</li>
        ))}
      </ul>
      <button onClick={handleBack} disabled={page === 0}>Back</button>
      <button onClick={handleNext} disabled={page + 1 >= totalPages}>Next</button>
    </>
  );
}

export default ViewAll;
