import { Link } from "react-router-dom"
function Admin(){
    return (
        <>
        <h1>You are at Admin page</h1>
        <Link>click here to visit Library</Link>
        <Link to="/library">click here to enter Library</Link>
        </>
    )
}
export default Admin