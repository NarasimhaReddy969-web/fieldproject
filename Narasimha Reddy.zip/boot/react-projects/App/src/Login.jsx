import { useState } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"
function Login(){
    const navigate=useNavigate()
    const[form,setform]=useState(
        {
            username:"",
            password:"",
        }
    )
    const changedata=(e)=>
        {
            setform({...form,[e.target.name]:e.target.value})
        }
    const submitform = async (e) => {
        e.preventDefault()
        try {
        const response=await axios.post("http://localhost:1234/login",form)
        if(response.data=="login success"){
            alert("login success")
            navigate("/admin")
        }
        else{
            alert("invalid username or password"+response.data)
        }
        }
        catch(error){
             console.error("Login error:", error)
            alert("An error occurred during login")
        }
};

    return(
        <>
            <h1>Login page</h1>
            <p>{form.username}</p>
            <p>{form.email}</p>
            <p>{form.password}</p>
            <form onSubmit={submitform}> 
                <input onChange={changedata}type="text" name="username" placeholder="enter name"/><br/>
                <input onChange={changedata}type="password" name="password" placeholder="enter password"/><br/>
                <button type="submit">Login</button><br/>
            </form>
        </>
    )
}
export default Login