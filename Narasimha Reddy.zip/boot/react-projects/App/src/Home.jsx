import {Link} from "react-router-dom";

function Home()
{
    return(
        <>
          <h1>Home Page</h1>
          <Link to="/reg">Click here to register</Link><br/>
          <Link to="/log">Login here</Link><br/>
          <Link to="/about">Go to About</Link><br></br>
        </>
    )
}
export default Home;