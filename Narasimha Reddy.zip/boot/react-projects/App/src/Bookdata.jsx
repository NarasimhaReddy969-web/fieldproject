import React, { useState, useEffect } from "react";
function Bookdata()
{
    const [name,setname] = useState ([]);
    useEffect(() =>
    {
        console.log("hi")

    },);
    const back = (e) =>
    {
        setname(name-1)

    }
    const next = (e) =>
    {
        setname(name+1)

    }
    return(
        <>
        <h1>view all data{n}</h1>
        <button onClick={back}>back</button>
        <button onClick={next}>next</button>
        </>
    )
}
export default Bookdata;