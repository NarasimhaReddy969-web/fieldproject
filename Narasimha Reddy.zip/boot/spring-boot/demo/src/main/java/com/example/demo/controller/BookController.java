package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Books;
import com.example.demo.repository.BookRepository;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "http://localhost:5173")
public class BookController {

    @Autowired
    BookRepository br;

    @PostMapping("/addbook")
    public String addBook(@RequestBody Books b) {
        Books result = this.br.findByTitle(b.getTitle());
        if (result != null) {
            return "The book already exists";
        } else {
            this.br.save(b);
            return "Book successfully created";
        }
    }

    @GetMapping("/all")
    public List<Books> viewAll() {
        return this.br.findAll();
    }

    @GetMapping("/authorform/{name}")
    public List<Books> viewByAuthor(@PathVariable("name") String name) {
        return this.br.findByAuthor(name);
    }
}
